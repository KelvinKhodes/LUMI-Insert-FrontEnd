
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/(default)" | "/(auth)" | "/" | "/(default)/about" | "/(default)/customer" | "/(default)/customer/list" | "/(default)/customer/new" | "/(default)/customer/[custId]" | "/(default)/customer/[custId]/edit" | "/(default)/customer/[custId]/view" | "/(default)/dashboard" | "/(auth)/login" | "/(default)/product" | "/(default)/product/list" | "/(default)/product/new" | "/(default)/product/stock" | "/(default)/transaction" | "/(default)/transaction/list" | "/(default)/transaction/new" | "/(default)/transaction/[trxId]" | "/(default)/transaction/[trxId]/create" | "/(default)/transaction/[trxId]/edit" | "/(default)/transaction/[trxId]/view";
		RouteParams(): {
			"/(default)/customer/[custId]": { custId: string };
			"/(default)/customer/[custId]/edit": { custId: string };
			"/(default)/customer/[custId]/view": { custId: string };
			"/(default)/transaction/[trxId]": { trxId: string };
			"/(default)/transaction/[trxId]/create": { trxId: string };
			"/(default)/transaction/[trxId]/edit": { trxId: string };
			"/(default)/transaction/[trxId]/view": { trxId: string }
		};
		LayoutParams(): {
			"/(default)": { custId?: string; trxId?: string };
			"/(auth)": Record<string, never>;
			"/": { custId?: string; trxId?: string };
			"/(default)/about": Record<string, never>;
			"/(default)/customer": { custId?: string };
			"/(default)/customer/list": Record<string, never>;
			"/(default)/customer/new": Record<string, never>;
			"/(default)/customer/[custId]": { custId: string };
			"/(default)/customer/[custId]/edit": { custId: string };
			"/(default)/customer/[custId]/view": { custId: string };
			"/(default)/dashboard": Record<string, never>;
			"/(auth)/login": Record<string, never>;
			"/(default)/product": Record<string, never>;
			"/(default)/product/list": Record<string, never>;
			"/(default)/product/new": Record<string, never>;
			"/(default)/product/stock": Record<string, never>;
			"/(default)/transaction": { trxId?: string };
			"/(default)/transaction/list": Record<string, never>;
			"/(default)/transaction/new": Record<string, never>;
			"/(default)/transaction/[trxId]": { trxId: string };
			"/(default)/transaction/[trxId]/create": { trxId: string };
			"/(default)/transaction/[trxId]/edit": { trxId: string };
			"/(default)/transaction/[trxId]/view": { trxId: string }
		};
		Pathname(): "/" | "/about" | "/about/" | "/customer" | "/customer/" | "/customer/list" | "/customer/list/" | "/customer/new" | "/customer/new/" | `/customer/${string}` & {} | `/customer/${string}/` & {} | `/customer/${string}/edit` & {} | `/customer/${string}/edit/` & {} | `/customer/${string}/view` & {} | `/customer/${string}/view/` & {} | "/dashboard" | "/dashboard/" | "/login" | "/login/" | "/product" | "/product/" | "/product/list" | "/product/list/" | "/product/new" | "/product/new/" | "/product/stock" | "/product/stock/" | "/transaction" | "/transaction/" | "/transaction/list" | "/transaction/list/" | "/transaction/new" | "/transaction/new/" | `/transaction/${string}` & {} | `/transaction/${string}/` & {} | `/transaction/${string}/create` & {} | `/transaction/${string}/create/` & {} | `/transaction/${string}/edit` & {} | `/transaction/${string}/edit/` & {} | `/transaction/${string}/view` & {} | `/transaction/${string}/view/` & {};
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}