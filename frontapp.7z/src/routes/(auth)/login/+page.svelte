<script lang="ts">
  import { FloatingLabelInput } from "flowbite-svelte";
</script> 

<head><title>Login</title></head>

<div class="h-screen flex flex-col">
  <div class="h-[6%]">Welcome to LUMI Insert</div>
  <form action="" class="h-[60%] w-[40%] flex flex-col self-center p-4 bg-gray-900 backdrop-blur-lg gap-3 rounded-2xl">
  <label for="login_username">Username</label>
  <FloatingLabelInput inputClass="text-gray-200" labelClass="bg-gray-900 text-gray-400" clearable variant="outlined" id="login_username" name="login_username" type="text" required>Your username here...</FloatingLabelInput>
  <label for="login_password">Password</label>
  <FloatingLabelInput inputClass="text-gray-200" labelClass="bg-gray-900 text-gray-400" clearable variant="outlined" id="login_password" name="login_password" type="text" required>Password goes here</FloatingLabelInput>
</form>
</div>
